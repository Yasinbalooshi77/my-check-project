/* The global section supplies trusted, escaped Liquid markup. Card slots also
   connect when Shopify replaces collection/recommendation sections via Ajax. */
(() => {
  if (customElements.get('valesco-inspired-label')) return;
  let templates = new Map();
  const slots = new Set();

  const refresh = () => {
    templates = new Map();
    document.querySelectorAll('valesco-inspiration-config template[data-product-id]').forEach((template) => {
      const productId = template.dataset.productId;
      if (!templates.has(productId)) templates.set(productId, template);
    });
    slots.forEach((slot) => slot.update());
  };

  class InspirationLabel extends HTMLElement {
    // Horizon can preserve this element while morphing its children to an
    // empty server-rendered slot. Watch this slot only, never the page tree.
    observer = new MutationObserver(() => this.update());
    static get observedAttributes() { return ['data-product-id']; }
    connectedCallback() {
      slots.add(this);
      this.update();
    }
    disconnectedCallback() {
      this.observer.disconnect();
      slots.delete(this);
    }
    attributeChangedCallback() { if (this.isConnected) this.update(); }
    update() {
      const template = templates.get(this.dataset.productId);
      // No image padding, DOM-wide observer, scroll handler or product fetch.
      this.observer.disconnect();
      this.replaceChildren(...(template ? [template.content.cloneNode(true)] : []));
      if (this.isConnected) this.observer.observe(this, { childList: true });
    }
  }

  refresh();
  customElements.define('valesco-inspired-label', InspirationLabel);

  if (window.Shopify?.designMode) {
    document.addEventListener('shopify:section:load', refresh);
    document.addEventListener('shopify:section:unload', () => queueMicrotask(refresh));
    document.addEventListener('shopify:section:reorder', refresh);
    document.addEventListener('shopify:block:select', (event) => {
      slots.forEach((slot) => {
        const label = slot.firstElementChild;
        label?.classList.toggle('is-editor-selected', label.dataset.inspirationBlock === event.detail.blockId);
      });
    });
    document.addEventListener('shopify:block:deselect', () => {
      slots.forEach((slot) => slot.firstElementChild?.classList.remove('is-editor-selected'));
    });
  }
})();
