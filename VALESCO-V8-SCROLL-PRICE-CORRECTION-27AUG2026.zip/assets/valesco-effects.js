(() => {
  if (window.__VALESCO_EFFECTS_V3__) return;
  window.__VALESCO_EFFECTS_V3__ = true;

  function revealNow(element) {
    element.classList.add('is-revealed');
  }

  function tuneStoryCarousels(scope = document) {
    const carousels = [];
    if (scope instanceof Element && scope.matches('.v-carousel--story[data-v-carousel]')) carousels.push(scope);
    if (scope?.querySelectorAll) carousels.push(...scope.querySelectorAll('.v-carousel--story[data-v-carousel]'));

    carousels.forEach((carousel) => {
      if (carousel.dataset.vStoryTouchTuned === 'true') return;
      carousel.dataset.vStoryTouchTuned = 'true';
    });
  }

  function mountReveals(scope = document) {
    const elements = [];
    if (scope instanceof Element && scope.matches('[data-v-reveal]')) elements.push(scope);
    if (scope?.querySelectorAll) elements.push(...scope.querySelectorAll('[data-v-reveal]'));

    elements.forEach((element) => {
      if (element.dataset.vRevealMounted === 'true') return;
      element.dataset.vRevealMounted = 'true';

      revealNow(element);
    });
  }

  function mountSpotlights(scope = document) {
    if (!window.matchMedia('(hover: hover) and (pointer: fine)').matches) return;
    const cards = [];
    if (scope instanceof Element && scope.matches('[data-v-card-effect="spotlight"]')) cards.push(scope);
    if (scope?.querySelectorAll) cards.push(...scope.querySelectorAll('[data-v-card-effect="spotlight"]'));

    cards.forEach((card) => {
      if (card.dataset.vSpotlightMounted === 'true') return;
      card.dataset.vSpotlightMounted = 'true';
      card.addEventListener('pointermove', (event) => {
        if (event.pointerType === 'touch') return;
        const rect = card.getBoundingClientRect();
        card.style.setProperty('--v-pointer-x', `${event.clientX - rect.left}px`);
        card.style.setProperty('--v-pointer-y', `${event.clientY - rect.top}px`);
      });
    });
  }

  // Only materialize hover images on devices that can use them.
  document.addEventListener('pointerover', (event) => {
    if (event.pointerType === 'touch' || !window.matchMedia('(hover: hover) and (pointer: fine)').matches) return;
    const card = event.target.closest?.('.valesco-product-card');
    const template = card?.querySelector('template[data-v-secondary-image]');
    if (!template) return;
    const image = template.content.querySelector('img');
    if (image) {
      image.loading = 'eager';
      image.addEventListener('load', () => card.classList.add('secondary-image-ready'), { once: true });
    }
    template.replaceWith(template.content);
  }, { passive: true });

  const mountedHeaders = new Set();
  let headerScrollScheduled = false;
  let headerMeasureScheduled = false;

  function syncHeaderMeasurements() {
    headerMeasureScheduled = false;
    const header = document.querySelector('[data-v-header]');
    if (!header) return;

    const height = Math.ceil(header.getBoundingClientRect().height);
    if (!height) return;

    const target = document.body;
    if (!target) return;
    for (const property of ['--header-height', '--header-height-static', '--header-group-height']) {
      if (target.style.getPropertyValue(property) !== height + 'px') target.style.setProperty(property, height + 'px');
    }
  }

  function scheduleHeaderMeasurement() {
    if (headerMeasureScheduled) return;
    headerMeasureScheduled = true;
    requestAnimationFrame(syncHeaderMeasurements);
  }

  function updateHeaders() {
    headerScrollScheduled = false;
    const scrolled = window.scrollY > 12 ? 'true' : 'false';
    mountedHeaders.forEach((header) => {
      if (!header.isConnected) {
        mountedHeaders.delete(header);
        return;
      }
      if (header.dataset.scrolled !== scrolled) header.dataset.scrolled = scrolled;
    });
  }

  function scheduleHeaderUpdate() {
    let glassHeaderEnabled = false;
    mountedHeaders.forEach((header) => {
      if (header.isConnected && header.dataset.glass === 'true') glassHeaderEnabled = true;
    });
    if (!glassHeaderEnabled) return;
    if (headerScrollScheduled) return;
    headerScrollScheduled = true;
    requestAnimationFrame(updateHeaders);
  }

  window.addEventListener('scroll', scheduleHeaderUpdate, { passive: true });
  window.addEventListener('resize', scheduleHeaderMeasurement, { passive: true });

  function mountHeaders(scope = document) {
    const headers = [];
    if (scope instanceof Element && scope.matches('[data-v-header]')) headers.push(scope);
    if (scope?.querySelectorAll) headers.push(...scope.querySelectorAll('[data-v-header]'));

    headers.forEach((header) => {
      if (header.dataset.vHeaderMounted === 'true') return;
      header.dataset.vHeaderMounted = 'true';
      mountedHeaders.add(header);
    });
    updateHeaders();
    scheduleHeaderMeasurement();
  }

  function mount(scope = document) {
    tuneStoryCarousels(scope);
    mountReveals(scope);
    mountSpotlights(scope);
    mountHeaders(scope);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => mount(document), { once: true });
  } else {
    mount(document);
  }

  document.addEventListener('shopify:section:load', (event) => mount(event.target));
  document.addEventListener('shopify:block:select', (event) => {
    const section = event.target.closest?.('[data-v-reveal]');
    if (section) revealNow(section);
  });
})();
