(() => {
  if (window.__VALESCO_LUXURY_2026__) return;
  window.__VALESCO_LUXURY_2026__ = true;

  const root = document.documentElement;
  const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
  let observer;
  let activeHeader;
  const pointerBindings = new WeakMap();

  const bool = (value) => value === 'true';

  function getConfig() {
    return document.querySelector('[data-valesco-luxury-config]');
  }

  function applyConfig() {
    const config = getConfig();
    if (!config) {
      root.classList.remove('valesco-luxury');
      return;
    }

    root.classList.add('valesco-luxury');
    root.dataset.vlSurface = config.dataset.surfaceStyle || 'quiet';
    root.dataset.vlDensity = config.dataset.density || 'air';
    root.dataset.vlMobileDensity = config.dataset.mobileDensity || 'balanced';
    root.dataset.vlMotion = (reduceMotion.matches || window.matchMedia('(pointer: coarse)').matches) ? 'off' : (config.dataset.motionLevel || 'subtle');
    root.dataset.vlReveal = config.dataset.revealStyle || 'fade_up';
    root.dataset.vlCardHover = config.dataset.cardHover || 'lift';
    root.dataset.vlHeaderGlass = bool(config.dataset.headerGlass) ? 'true' : 'false';
    root.dataset.vlProductFrame = bool(config.dataset.productFrame) ? 'true' : 'false';
    root.dataset.vlButtonSheen = bool(config.dataset.buttonSheen) ? 'true' : 'false';
    root.dataset.vlSoftMedia = bool(config.dataset.softMedia) ? 'true' : 'false';
    root.dataset.vlElevatedCart = bool(config.dataset.elevatedCart) ? 'true' : 'false';
    root.style.setProperty('--vl-product-stagger', `${Number(config.dataset.productStagger || 60)}ms`);
    root.style.setProperty('--vl-spotlight-strength', `${Number(config.dataset.spotlightStrength || 15)}%`);
  }

  function visibleImmediately(el) {
    const rect = el.getBoundingClientRect();
    return rect.top < window.innerHeight * 1.05;
  }

  function clearRevealObserver() {
    if (observer) observer.disconnect();
    observer = undefined;
  }

  function setupReveals(scope = document) {
    clearRevealObserver();
    root.classList.remove('vl-reveal-ready');

    if (root.dataset.vlMotion === 'off') {
      return;
    }

    const items = [];

    scope.querySelectorAll('.product-grid').forEach((grid) => {
      Array.from(grid.querySelectorAll(':scope > .product-grid__item')).forEach((item, index) => {
        if (index >= 4) {
          item.dataset.vlReveal = '';
          item.style.setProperty('--vl-item-index', String((index - 4) % 6));
          items.push(item);
        }
      });
    });

    scope.querySelectorAll('.facets, .cart-drawer__summary, .product-form-buttons').forEach((el) => {
      if (!el.closest('[data-v-carousel]')) {
        el.dataset.vlReveal = '';
        items.push(el);
      }
    });

    document.querySelectorAll('[data-vl-reveal]').forEach((el) => {
      if (!items.includes(el)) items.push(el);
    });

    items.forEach((el) => {
      if (visibleImmediately(el)) el.classList.add('is-vl-visible');
    });

    const pending = items.filter((el) => !el.classList.contains('is-vl-visible'));
    if (!pending.length || !('IntersectionObserver' in window)) {
      pending.forEach((el) => el.classList.add('is-vl-visible'));
      return;
    }

    observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (!entry.isIntersecting) return;
        entry.target.classList.add('is-vl-visible');
        observer.unobserve(entry.target);
      });
    }, { rootMargin: '0px 0px -8% 0px', threshold: 0.08 });

    pending.forEach((el) => observer.observe(el));
    requestAnimationFrame(() => root.classList.add('vl-reveal-ready'));
  }

  function setupPointerEffects(scope = document) {
    const cards = [];
    if (scope instanceof Element && scope.matches('product-card.product-card, .valesco-product-card')) cards.push(scope);
    if (scope?.querySelectorAll) cards.push(...scope.querySelectorAll('product-card.product-card, .valesco-product-card'));

    cards.forEach((card) => {
      const existing = pointerBindings.get(card);
      const shouldBind = root.dataset.vlCardHover === 'spotlight' && window.matchMedia('(hover: hover) and (pointer: fine)').matches;

      if (!shouldBind) {
        if (existing) {
          card.removeEventListener('pointermove', existing);
          pointerBindings.delete(card);
        }
        return;
      }

      if (existing) return;

      const move = (event) => {
        const rect = card.getBoundingClientRect();
        const x = ((event.clientX - rect.left) / Math.max(rect.width, 1)) * 100;
        const y = ((event.clientY - rect.top) / Math.max(rect.height, 1)) * 100;
        card.style.setProperty('--vl-pointer-x', `${x}%`);
        card.style.setProperty('--vl-pointer-y', `${y}%`);
      };

      card.addEventListener('pointermove', move, { passive: true });
      pointerBindings.set(card, move);
    });
  }

  function updateHeader() {
    if (root.dataset.vlHeaderGlass !== 'true' && !activeHeader?.classList.contains('is-vl-scrolled')) return;
    if (!activeHeader?.isConnected) {
      activeHeader = document.querySelector('[data-v-header]') || undefined;
    }
    if (root.dataset.vlHeaderGlass !== 'true') {
      if (activeHeader?.classList.contains('is-vl-scrolled')) activeHeader.classList.remove('is-vl-scrolled');
      return;
    }
    activeHeader?.classList.toggle('is-vl-scrolled', window.scrollY > 12);
  }

  function enhanceHeader() {
    activeHeader = document.querySelector('[data-v-header]') || undefined;
    updateHeader();
  }

  function boot(scope = document) {
    applyConfig();
    enhanceHeader();
    setupReveals(scope);
    setupPointerEffects(scope);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => boot(document), { once: true });
  } else {
    boot(document);
  }

  reduceMotion.addEventListener?.('change', () => boot(document));
  window.addEventListener('scroll', updateHeader, { passive: true });

  document.addEventListener('shopify:section:load', (event) => {
    requestAnimationFrame(() => boot(event.target));
  });

  document.addEventListener('shopify:section:unload', () => {
    requestAnimationFrame(() => boot(document));
  });

  document.addEventListener('shopify:section:reorder', () => {
    requestAnimationFrame(() => boot(document));
  });
})();
