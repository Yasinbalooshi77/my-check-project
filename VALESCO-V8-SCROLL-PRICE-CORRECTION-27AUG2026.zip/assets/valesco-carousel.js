(() => {
  if (window.__VALESCO_NATIVE_CAROUSEL__) return;
  window.__VALESCO_NATIVE_CAROUSEL__ = true;
  const selector = '[data-v-carousel][data-transition="native"]';
  const instances = new WeakMap();
  let legacyRequested = false;

  class NativeCarousel {
    constructor(root) {
      this.root = root;
      this.viewport = root.querySelector('[data-v-viewport]');
      this.slides = [...root.querySelectorAll('[data-v-slide]')];
      this.dots = [...root.querySelectorAll('[data-v-dot]')];
      this.current = root.querySelector('[data-v-current]');
      this.status = root.querySelector('[data-v-status]');
      this.abort = new AbortController();
      this.reduced = matchMedia('(prefers-reduced-motion: reduce)');
      this.index = 0;
      this.positions = [];
      this.drag = null;
      this.suppressClick = false;
      if (!this.viewport || !this.slides.length) return;
      const signal = this.abort.signal;
      const listen = (el, name, fn, options = {}) => el?.addEventListener(name, fn, { signal, ...options });
      this.slides.forEach(slide => { slide.hidden = false; });
      this.select(0);
      listen(root.querySelector('[data-v-prev]'), 'click', () => this.go(this.index - 1));
      listen(root.querySelector('[data-v-next]'), 'click', () => this.go(this.index + 1));
      this.dots.forEach((dot, index) => listen(dot, 'click', () => this.go(index)));
      listen(root, 'keydown', event => {
        if (event.target.closest('a, input, textarea, select')) return;
        const rtl = getComputedStyle(root).direction === 'rtl';
        let target;
        if (event.key === 'ArrowRight') target = this.index + (rtl ? -1 : 1);
        if (event.key === 'ArrowLeft') target = this.index + (rtl ? 1 : -1);
        if (event.key === 'Home') target = 0;
        if (event.key === 'End') target = this.slides.length - 1;
        if (target === undefined) return;
        event.preventDefault();
        this.go(target);
      });
      // Touch is entirely browser-owned. Never capture or cancel touch gestures.
      listen(this.viewport, 'pointerdown', event => {
        this.suppressClick = false;
        if (event.pointerType !== 'mouse' || event.button !== 0 || root.dataset.swipe === 'false') return;
        this.suppressClick = false;
        this.drag = { id: event.pointerId, x: event.clientX, start: this.viewport.scrollLeft, moved: false };
      }, { passive: true });
      listen(this.viewport, 'pointermove', event => {
        const drag = this.drag;
        if (!drag || drag.id !== event.pointerId || event.pointerType !== 'mouse') return;
        const dx = event.clientX - drag.x;
        if (!drag.moved && Math.abs(dx) < 8) return;
        if (!drag.moved) {
          drag.moved = true;
          root.classList.add('is-native-dragging');
          this.viewport.setPointerCapture(event.pointerId);
        }
        this.viewport.scrollLeft = drag.start - dx;
      }, { passive: true });
      const release = () => {
        if (!this.drag) return;
        const moved = this.drag.moved;
        this.drag = null;
        root.classList.remove('is-native-dragging');
        if (moved) {
          this.suppressClick = true;
          this.go(this.nearest(), false);
        }
      };
      listen(this.viewport, 'pointerup', release, { passive: true });
      listen(this.viewport, 'pointercancel', release, { passive: true });
      listen(this.viewport, 'lostpointercapture', release, { passive: true });
      listen(this.viewport, 'pointerleave', () => { if (!this.drag?.moved) this.drag = null; }, { passive: true });
      listen(root, 'click', event => {
        if (!this.suppressClick) return;
        this.suppressClick = false;
        event.preventDefault();
        event.stopPropagation();
      }, { capture: true });
      listen(this.viewport, 'dragstart', event => event.preventDefault());
      // One update after settling, with a fallback for older Samsung Internet.
      const settle = () => {
        clearTimeout(this.settleTimer);
        if (!this.drag) this.select(this.nearest());
      };
      listen(this.viewport, 'scrollend', settle, { passive: true });
      listen(this.viewport, 'scroll', () => {
        clearTimeout(this.settleTimer);
        this.settleTimer = setTimeout(settle, 140);
      }, { passive: true });
      const scheduleMeasure = () => {
        cancelAnimationFrame(this.measureFrame);
        this.measureFrame = requestAnimationFrame(() => this.measure());
      };
      if ('ResizeObserver' in window) {
        this.resize = new ResizeObserver(scheduleMeasure);
        this.resize.observe(this.viewport);
      } else listen(window, 'resize', scheduleMeasure, { passive: true });
      scheduleMeasure();
      root.dataset.vReady = 'true';
    }
    measure() {
      // Read layout as one batch, never in a touch/pointer-move handler.
      const box = this.viewport.getBoundingClientRect();
      const start = this.viewport.scrollLeft;
      const rtl = getComputedStyle(this.root).direction === 'rtl';
      const max = Math.max(0, this.viewport.scrollWidth - this.viewport.clientWidth);
      this.positions = this.slides.map(slide => {
        const rect = slide.getBoundingClientRect();
        const center = start + rect.left + rect.width / 2 - box.left - box.width / 2;
        return rtl ? Math.max(-max, Math.min(0, center)) : Math.min(max, Math.max(0, center));
      });
    }
    nearest() {
      const offset = this.viewport.scrollLeft;
      return this.positions.reduce((best, position, index) =>
        Math.abs(position - offset) < Math.abs(this.positions[best] - offset) ? index : best, 0);
    }
    select(index) {
      this.index = index;
      this.slides.forEach((slide, i) => {
        const active = i === index;
        slide.classList.toggle('is-active', active);
        slide.setAttribute('aria-hidden', String(!active));
        slide.inert = !active;
        slide.querySelectorAll('a, button').forEach(control => {
          if (!control.hasAttribute('data-v-original-tabindex')) control.dataset.vOriginalTabindex = control.getAttribute('tabindex') ?? '';
          if (active) {
            if (control.dataset.vOriginalTabindex === '') control.removeAttribute('tabindex');
            else control.setAttribute('tabindex', control.dataset.vOriginalTabindex);
          } else control.setAttribute('tabindex', '-1');
        });
      });
      this.dots.forEach((dot, i) => dot.setAttribute('aria-current', String(i === index)));
      if (this.current) this.current.textContent = String(index + 1);
      if (this.announce && this.status) {
        this.status.textContent = `الشريحة ${index + 1} من ${this.slides.length}`;
        this.announce = false;
      }
    }
    go(target, announce = true, instant = false) {
      if (!this.positions.length) this.measure();
      const wrapped = (target + this.slides.length) % this.slides.length;
      this.announce = announce;
      // Wrapping via arrows doesn't sweep across all intervening slides.
      const wrap = target < 0 || target >= this.slides.length;
      this.viewport.scrollTo({ left: this.positions[wrapped], behavior: instant || wrap || this.reduced.matches ? 'instant' : 'smooth' });
      this.select(wrapped);
    }
    destroy() {
      this.abort.abort();
      this.resize?.disconnect();
      clearTimeout(this.settleTimer);
      cancelAnimationFrame(this.measureFrame);
    }
  }
  function roots(scope) {
    return [...(scope.matches?.(selector) ? [scope] : []), ...scope.querySelectorAll(selector)];
  }
  function mount(scope = document) {
    roots(scope).forEach(root => {
      if (!instances.has(root)) instances.set(root, new NativeCarousel(root));
    });
    const legacy = document.querySelector('[data-v-carousel]:not([data-transition="native"])');
    if (legacy && !legacyRequested && legacy.dataset.legacyScript) {
      legacyRequested = true;
      const script = document.createElement('script');
      script.src = legacy.dataset.legacyScript;
      script.onerror = () => { legacyRequested = false; script.remove(); };
      document.head.append(script);
    }
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', () => mount(), { once: true });
  else mount();
  document.addEventListener('shopify:section:load', event => mount(event.target));
  document.addEventListener('shopify:section:unload', event => roots(event.target).forEach(root => {
    instances.get(root)?.destroy(); instances.delete(root);
  }));
  document.addEventListener('shopify:block:select', event => {
    const slide = event.target.closest?.('[data-v-slide]');
    const root = slide?.closest(selector);
    if (root) instances.get(root)?.go(Number(slide.dataset.vSlideIndex), false, true);
  });
})();
