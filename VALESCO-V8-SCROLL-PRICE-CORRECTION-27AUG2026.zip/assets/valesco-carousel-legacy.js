(() => {
  if (window.__VALESCO_CAROUSEL_V3__) return;
  window.__VALESCO_CAROUSEL_V3__ = true;

  const SELECTOR = '[data-v-carousel]:not([data-transition="native"])';
  const instances = new WeakMap();

  class ValescoCarousel {
    constructor(root) {
      this.root = root;
      this.viewport = root.querySelector('[data-v-viewport]');
      this.slides = Array.from(root.querySelectorAll('[data-v-slide]'));
      this.prevButton = root.querySelector('[data-v-prev]');
      this.nextButton = root.querySelector('[data-v-next]');
      this.dots = Array.from(root.querySelectorAll('[data-v-dot]'));
      this.currentLabel = root.querySelector('[data-v-current]');
      this.status = root.querySelector('[data-v-status]');
      this.index = Math.max(0, this.slides.findIndex((slide) => slide.classList.contains('is-active')));
      this.animating = false;
      this.pending = null;
      this.transitionTimer = null;
      this.dragTimer = null;
      this.drag = null;
      this.suppressClickUntil = 0;
      this.abortController = new AbortController();
      this.reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
      this.rtl = window.getComputedStyle(root).direction === 'rtl';
    }

    mount() {
      if (!this.viewport || !this.slides.length) return;

      this.slides.forEach((slide, slideIndex) => {
        slide.dataset.vSlideIndex = String(slideIndex);
        this.setSlideState(slide, slideIndex === this.index);
        slide.querySelectorAll('img').forEach((image) => {
          image.draggable = false;
        });
      });

      const signal = this.abortController.signal;

      this.prevButton?.addEventListener('click', () => this.prev(true), { signal });
      this.nextButton?.addEventListener('click', () => this.next(true), { signal });

      this.dots.forEach((dot) => {
        dot.addEventListener('click', () => {
          const target = Number(dot.dataset.vDot);
          const direction = target >= this.index ? 'next' : 'prev';
          this.goTo(target, { direction, announce: true });
        }, { signal });
      });

      this.root.addEventListener('keydown', (event) => this.onKeydown(event), { signal });
      this.root.addEventListener('click', (event) => this.onClickCapture(event), { signal, capture: true });
      this.viewport.addEventListener('pointerdown', (event) => this.onPointerDown(event), { signal });
      this.viewport.addEventListener('pointermove', (event) => this.onPointerMove(event), { signal });
      this.viewport.addEventListener('pointerup', (event) => this.onPointerUp(event), { signal });
      this.viewport.addEventListener('pointercancel', (event) => this.onPointerCancel(event), { signal });

      this.updateUi(false);
      this.root.dataset.vReady = 'true';
    }

    destroy() {
      this.cancelDragImmediate();
      this.completeTransition();
      this.abortController.abort();
      this.root.removeAttribute('data-v-ready');
    }

    get swipeEnabled() {
      return this.root.dataset.swipe !== 'false';
    }

    get swipeDistancePercent() {
      const value = Number.parseFloat(this.root.dataset.swipeDistance || '8');
      return Number.isFinite(value) ? Math.min(22, Math.max(4, value)) : 8;
    }

    get flickVelocity() {
      const value = Number.parseFloat(this.root.dataset.flickVelocity || '0.32');
      return Number.isFinite(value) ? Math.min(1.2, Math.max(0.12, value)) : 0.32;
    }

    get duration() {
      if (this.reducedMotion.matches) return 0;
      const value = parseInt(window.getComputedStyle(this.root).getPropertyValue('--v-duration'), 10);
      return Number.isFinite(value) ? Math.max(0, value) : 460;
    }

    get snapDuration() {
      if (this.reducedMotion.matches) return 0;
      const value = parseInt(window.getComputedStyle(this.root).getPropertyValue('--v-snap-duration'), 10);
      return Number.isFinite(value) ? Math.max(120, value) : 300;
    }

    normalize(index) {
      const count = this.slides.length;
      return ((index % count) + count) % count;
    }

    clearMotionStyles(slide) {
      if (!slide) return;
      slide.style.removeProperty('transform');
      slide.style.removeProperty('opacity');
      slide.style.removeProperty('z-index');
    }

    setSlideState(slide, active) {
      this.clearMotionStyles(slide);
      slide.classList.remove('is-entering', 'is-leaving', 'is-drag-current', 'is-drag-target');

      if (active) {
        slide.hidden = false;
        slide.removeAttribute('inert');
        slide.setAttribute('aria-hidden', 'false');
        slide.classList.add('is-active');
      } else {
        slide.hidden = true;
        slide.setAttribute('inert', '');
        slide.setAttribute('aria-hidden', 'true');
        slide.classList.remove('is-active');
      }
    }

    next(announce = false) {
      this.goTo(this.index + 1, { direction: 'next', announce });
    }

    prev(announce = false) {
      this.goTo(this.index - 1, { direction: 'prev', announce });
    }

    goTo(rawTarget, { direction = 'next', announce = false, animate = true } = {}) {
      if (this.slides.length < 2 || this.drag) return;

      const target = this.normalize(rawTarget);

      if (this.animating && !animate) {
        this.completeTransition();
      }

      if (this.animating || target === this.index) return;

      const outgoing = this.slides[this.index];
      const incoming = this.slides[target];
      const duration = animate ? this.duration : 0;

      if (duration === 0) {
        this.setSlideState(outgoing, false);
        this.index = target;
        this.setSlideState(incoming, true);
        this.updateUi(announce);
        return;
      }

      this.animating = true;
      this.pending = { outgoing, incoming, target, announce };

      const sign = this.directionSign(direction);
      this.root.style.setProperty('--v-enter-x', `${sign * 100}%`);
      this.root.style.setProperty('--v-leave-x', `${sign * -100}%`);

      const outgoingHeight = outgoing.getBoundingClientRect().height;
      incoming.hidden = false;
      incoming.setAttribute('inert', '');
      incoming.setAttribute('aria-hidden', 'true');
      incoming.classList.add('is-entering');

      const incomingHeight = incoming.getBoundingClientRect().height;
      this.viewport.style.height = `${Math.max(outgoingHeight, incomingHeight)}px`;

      outgoing.classList.add('is-leaving');

      requestAnimationFrame(() => {
        requestAnimationFrame(() => {
          if (!this.pending) return;
          this.root.classList.add('is-transitioning');
        });
      });

      this.transitionTimer = window.setTimeout(() => this.completeTransition(), duration + 100);
    }

    completeTransition() {
      if (!this.pending) {
        this.animating = false;
        if (this.transitionTimer) {
          window.clearTimeout(this.transitionTimer);
          this.transitionTimer = null;
        }
        return;
      }

      if (this.transitionTimer) {
        window.clearTimeout(this.transitionTimer);
        this.transitionTimer = null;
      }

      const { outgoing, incoming, target, announce } = this.pending;

      if (outgoing.contains(document.activeElement)) {
        this.root.focus({ preventScroll: true });
      }

      this.root.classList.remove('is-transitioning');
      this.setSlideState(outgoing, false);
      this.index = target;
      this.setSlideState(incoming, true);
      this.pending = null;
      this.animating = false;

      this.viewport.style.height = `${incoming.getBoundingClientRect().height}px`;
      requestAnimationFrame(() => {
        this.viewport.style.height = '';
      });

      this.updateUi(announce);
    }

    updateUi(announce = false) {
      this.dots.forEach((dot, dotIndex) => {
        dot.setAttribute('aria-current', dotIndex === this.index ? 'true' : 'false');
      });

      if (this.currentLabel) {
        this.currentLabel.textContent = String(this.index + 1);
      }

      if (announce && this.status) {
        this.status.textContent = `الشريحة ${this.index + 1} من ${this.slides.length}`;
      }
    }

    onKeydown(event) {
      if (event.defaultPrevented || this.drag) return;

      if (event.key === 'ArrowRight') {
        event.preventDefault();
        this.rtl ? this.prev(true) : this.next(true);
      } else if (event.key === 'ArrowLeft') {
        event.preventDefault();
        this.rtl ? this.next(true) : this.prev(true);
      } else if (event.key === 'Home') {
        event.preventDefault();
        this.goTo(0, { direction: 'prev', announce: true });
      } else if (event.key === 'End') {
        event.preventDefault();
        this.goTo(this.slides.length - 1, { direction: 'next', announce: true });
      }
    }

    onClickCapture(event) {
      if (performance.now() > this.suppressClickUntil) return;
      if (!(event.target instanceof Element)) return;
      const link = event.target.closest('a');
      if (!link) return;
      event.preventDefault();
      event.stopPropagation();
    }

    onPointerDown(event) {
      if (!this.swipeEnabled || this.slides.length < 2 || this.drag) return;
      if (!event.isPrimary || (event.pointerType === 'mouse' && event.button !== 0)) return;
      if (event.target.closest('button, input, select, textarea, [contenteditable="true"]')) return;

      // Let a new gesture take control immediately instead of making the user
      // wait for the previous snap animation to finish.
      if (this.animating) this.completeTransition();

      const now = performance.now();
      this.drag = {
        pointerId: event.pointerId,
        width: Math.max(1, this.viewport.getBoundingClientRect().width),
        startX: event.clientX,
        startY: event.clientY,
        lastX: event.clientX,
        lastY: event.clientY,
        lastT: now,
        velocityX: 0,
        axis: null,
        dx: 0,
        direction: null,
        targetIndex: null,
        outgoing: null,
        incoming: null,
        entryOffset: 0,
        moved: false,
        settling: false
      };
      this.root.classList.add('is-pointer-ready');
    }

    onPointerMove(event) {
      const drag = this.drag;
      if (!drag || drag.pointerId !== event.pointerId || drag.settling) return;

      const dx = event.clientX - drag.startX;
      const dy = event.clientY - drag.startY;
      const absX = Math.abs(dx);
      const absY = Math.abs(dy);

      if (!drag.axis) {
        if (Math.max(absX, absY) < 3) return;

        if (absX >= absY * 0.9) {
          drag.axis = 'x';
          this.root.classList.remove('is-pointer-ready');
          this.root.classList.add('is-dragging');
          this.viewport.setPointerCapture?.(event.pointerId);
        } else if (absY >= absX * 1.15) {
          drag.axis = 'y';
          this.root.classList.remove('is-pointer-ready');
          return;
        } else {
          return;
        }
      }

      if (drag.axis !== 'x') return;

      event.preventDefault();
      const now = performance.now();
      const dt = Math.max(1, now - drag.lastT);
      const instantVelocity = (event.clientX - drag.lastX) / dt;
      drag.velocityX = drag.velocityX * 0.58 + instantVelocity * 0.42;
      drag.lastX = event.clientX;
      drag.lastY = event.clientY;
      drag.lastT = now;
      drag.dx = dx;
      drag.moved = drag.moved || absX > 7;

      const direction = this.directionForDx(dx);
      if (direction && direction !== drag.direction) {
        this.prepareDrag(direction);
      }

      if (drag.direction) {
        this.renderDrag(dx);
      }
    }

    onPointerUp(event) {
      const drag = this.drag;
      if (!drag || drag.pointerId !== event.pointerId || drag.settling) return;

      const dx = event.clientX - drag.startX;
      const dy = event.clientY - drag.startY;

      if (drag.axis !== 'x') {
        if (Math.abs(dx) >= 12 && Math.abs(dx) >= Math.abs(dy) * 0.8) {
          drag.axis = 'x';
          drag.moved = true;
          this.root.classList.remove('is-pointer-ready');
          this.root.classList.add('is-dragging');
          this.prepareDrag(this.directionForDx(dx));
          this.renderDrag(dx);
        } else {
          this.resetPointer();
          return;
        }
      }

      event.preventDefault();
      drag.dx = dx;

      if (performance.now() - drag.lastT > 90) {
        drag.velocityX *= 0.45;
      }

      const width = drag.width;
      const distanceThreshold = Math.max(16, Math.min(48, width * (this.swipeDistancePercent / 100)));
      const projectedDx = dx + drag.velocityX * 170;
      const hasDistance = Math.abs(dx) >= distanceThreshold;
      const hasFlick = Math.abs(drag.velocityX) >= this.flickVelocity;
      const hasProjection = Math.abs(projectedDx) >= distanceThreshold * 0.9;
      const commit = (hasDistance || hasFlick || hasProjection) && Math.abs(dx) > Math.abs(dy) * 0.65;

      let direction = drag.direction;
      if (commit) {
        const intentDx = hasFlick && Math.abs(dx) < distanceThreshold ? drag.velocityX : (Math.abs(projectedDx) > Math.abs(dx) ? projectedDx : dx);
        direction = this.directionForDx(intentDx) || direction;
      }

      if (direction && direction !== drag.direction) {
        this.prepareDrag(direction);
        this.renderDrag(dx);
      }

      if (drag.moved) {
        this.suppressClickUntil = performance.now() + 450;
      }

      this.settleDrag(Boolean(commit && direction), true);
    }

    onPointerCancel(event) {
      const drag = this.drag;
      if (!drag || drag.pointerId !== event.pointerId || drag.settling) return;
      if (drag.axis === 'x' && drag.direction) {
        this.settleDrag(false, false);
      } else {
        this.resetPointer();
      }
    }

    directionForDx(dx) {
      if (Math.abs(dx) < 0.01) return null;
      if (this.rtl) return dx > 0 ? 'next' : 'prev';
      return dx < 0 ? 'next' : 'prev';
    }

    directionSign(direction) {
      const physicalFlow = this.rtl ? -1 : 1;
      const logicalMove = direction === 'prev' ? -1 : 1;
      return physicalFlow * logicalMove;
    }

    prepareDrag(direction) {
      const drag = this.drag;
      if (!drag) return;

      if (drag.incoming) {
        this.clearMotionStyles(drag.incoming);
        drag.incoming.classList.remove('is-entering', 'is-drag-target');
        drag.incoming.hidden = true;
        drag.incoming.setAttribute('inert', '');
        drag.incoming.setAttribute('aria-hidden', 'true');
      }

      if (drag.outgoing) {
        this.clearMotionStyles(drag.outgoing);
        drag.outgoing.classList.remove('is-leaving', 'is-drag-current');
      }

      const targetIndex = this.normalize(this.index + (direction === 'next' ? 1 : -1));
      const outgoing = this.slides[this.index];
      const incoming = this.slides[targetIndex];
      const width = drag.width;
      const sign = this.directionSign(direction);
      const entryOffset = sign * width;

      drag.direction = direction;
      drag.targetIndex = targetIndex;
      drag.outgoing = outgoing;
      drag.incoming = incoming;
      drag.entryOffset = entryOffset;

      this.root.style.setProperty('--v-enter-x', `${sign * 100}%`);
      this.root.style.setProperty('--v-leave-x', `${sign * -100}%`);

      const outgoingHeight = outgoing.getBoundingClientRect().height;
      incoming.hidden = false;
      incoming.setAttribute('inert', '');
      incoming.setAttribute('aria-hidden', 'true');
      incoming.classList.add('is-entering', 'is-drag-target');
      outgoing.classList.add('is-leaving', 'is-drag-current');

      const incomingHeight = incoming.getBoundingClientRect().height;
      this.viewport.style.height = `${Math.max(outgoingHeight, incomingHeight)}px`;
    }

    renderDrag(rawDx) {
      const drag = this.drag;
      if (!drag?.outgoing || !drag?.incoming) return;

      const width = drag.width;
      const dx = Math.max(-width * 0.96, Math.min(width * 0.96, rawDx));
      const progress = Math.min(1, Math.abs(dx) / width);
      this.root.style.setProperty('--v-drag-progress', progress.toFixed(4));

      if (this.root.dataset.transition === 'fade') {
        drag.outgoing.style.opacity = String(Math.max(0.18, 1 - progress));
        drag.incoming.style.opacity = String(Math.min(1, progress + 0.04));
      } else {
        drag.outgoing.style.transform = `translate3d(${dx}px, 0, 0)`;
        drag.incoming.style.transform = `translate3d(${drag.entryOffset + dx}px, 0, 0)`;
      }
    }

    settleDrag(commit, announce) {
      const drag = this.drag;
      if (!drag?.outgoing || !drag?.incoming) {
        this.resetPointer();
        return;
      }

      drag.settling = true;
      this.animating = true;
      this.root.classList.remove('is-pointer-ready', 'is-dragging');
      this.root.classList.add('is-settling');

      const duration = this.snapDuration;
      const outgoingTarget = commit ? -drag.entryOffset : 0;
      const incomingTarget = commit ? 0 : drag.entryOffset;

      const finish = () => this.finishDrag(commit, announce);

      if (duration === 0) {
        finish();
        return;
      }

      // Force the browser to commit the finger-following frame before snapping.
      drag.outgoing.getBoundingClientRect();

      requestAnimationFrame(() => {
        if (!this.drag) return;
        if (this.root.dataset.transition === 'fade') {
          drag.outgoing.style.opacity = commit ? '0' : '1';
          drag.incoming.style.opacity = commit ? '1' : '0';
        } else {
          drag.outgoing.style.transform = `translate3d(${outgoingTarget}px, 0, 0)`;
          drag.incoming.style.transform = `translate3d(${incomingTarget}px, 0, 0)`;
        }
      });

      this.dragTimer = window.setTimeout(finish, duration + 90);
    }

    finishDrag(commit, announce) {
      const drag = this.drag;
      if (!drag) return;

      if (this.dragTimer) {
        window.clearTimeout(this.dragTimer);
        this.dragTimer = null;
      }

      this.root.classList.remove('is-pointer-ready', 'is-dragging', 'is-settling');
      this.root.style.removeProperty('--v-drag-progress');

      if (commit) {
        this.setSlideState(drag.outgoing, false);
        this.index = drag.targetIndex;
        this.setSlideState(drag.incoming, true);
      } else {
        this.setSlideState(drag.incoming, false);
        this.setSlideState(drag.outgoing, true);
      }

      const active = this.slides[this.index];
      this.viewport.style.height = `${active.getBoundingClientRect().height}px`;
      requestAnimationFrame(() => {
        this.viewport.style.height = '';
      });

      this.drag = null;
      this.animating = false;
      this.updateUi(commit && announce);
    }

    cancelDragImmediate() {
      if (!this.drag) return;
      if (this.dragTimer) {
        window.clearTimeout(this.dragTimer);
        this.dragTimer = null;
      }
      const drag = this.drag;
      this.root.classList.remove('is-pointer-ready', 'is-dragging', 'is-settling');
      this.root.style.removeProperty('--v-drag-progress');
      if (drag.incoming) this.setSlideState(drag.incoming, false);
      if (drag.outgoing) this.setSlideState(drag.outgoing, true);
      this.viewport.style.height = '';
      this.drag = null;
      this.animating = false;
    }

    resetPointer() {
      this.root.classList.remove('is-pointer-ready', 'is-dragging');
      this.drag = null;
    }

    selectBlock(blockElement) {
      const slide = blockElement.closest('[data-v-slide]');
      if (!slide) return;

      const target = Number(slide.dataset.vSlideIndex);
      if (!Number.isInteger(target)) return;

      this.cancelDragImmediate();
      this.goTo(target, {
        direction: target >= this.index ? 'next' : 'prev',
        announce: false,
        animate: false
      });
    }
  }

  function rootsInside(scope) {
    const roots = [];
    if (scope instanceof Element && scope.matches(SELECTOR)) roots.push(scope);
    if (scope?.querySelectorAll) roots.push(...scope.querySelectorAll(SELECTOR));
    return roots;
  }

  function mount(root) {
    if (instances.has(root)) return;
    const instance = new ValescoCarousel(root);
    instances.set(root, instance);
    instance.mount();
  }

  function mountAll(scope = document) {
    rootsInside(scope).forEach(mount);
  }

  function destroyAll(scope) {
    rootsInside(scope).forEach((root) => {
      const instance = instances.get(root);
      if (!instance) return;
      instance.destroy();
      instances.delete(root);
    });
  }

  function boot() {
    document.querySelectorAll(SELECTOR).forEach(mount);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot, { once: true });
  } else {
    boot();
  }

  document.addEventListener('shopify:section:load', (event) => mountAll(event.target));
  document.addEventListener('shopify:section:unload', (event) => destroyAll(event.target));
  document.addEventListener('shopify:block:select', (event) => {
    const block = event.target instanceof Element ? event.target : null;
    if (!block) return;
    const root = block.closest(SELECTOR);
    const instance = root ? instances.get(root) : null;
    instance?.selectBlock(block);
  });
})();
