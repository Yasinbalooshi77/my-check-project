/** Choose unseen products first, then least recently shown. IDs stay strings. */
export function chooseRecommendationIds(candidateIds, currentId, history, limit, random = Math.random) {
  const unique = [...new Set(candidateIds.map(String))].filter(id => id && id !== String(currentId));
  const recent = Array.isArray(history) ? history.map(String) : [];
  // Shuffle ties only; recent impressions always rank behind unseen candidates.
  const ranked = unique.map(id => ({ id, age: recent.lastIndexOf(id), tie: random() }));
  ranked.sort((a, b) => a.age - b.age || a.tie - b.tie);
  return ranked.slice(0, Math.max(0, Number(limit) || 4)).map(item => item.id);
}

export function trimRecommendationResponse(html, currentId, displayLimit) {
  const template = document.createElement('template');
  template.innerHTML = html;
  const section = template.content.querySelector('product-recommendations[data-variety="true"]');
  if (!section) return html;
  const cards = [...section.querySelectorAll('[data-recommendation-id]')];
  if (!cards.length) return html;
  const key = 'valesco-recommendations-v6';
  let history = [];
  try {
    const stored = JSON.parse(sessionStorage.getItem(key) || '[]');
    if (Array.isArray(stored)) history = stored.filter(id => typeof id === 'string').slice(-250);
  } catch { /* Private browsing or disabled storage must not break recommendations. */ }
  const chosen = chooseRecommendationIds(cards.map(card => card.dataset.recommendationId), currentId, history, displayLimit);
  const selected = new Set(chosen);
  for (const card of cards) {
    const id = card.dataset.recommendationId;
    if (!selected.has(id)) card.remove();
    else selected.delete(id); // Also eliminate accidental duplicate cards.
  }
  section.dataset.recommendationsPerformed = 'true';
  try {
    const next = history.filter(id => id !== String(currentId) && !chosen.includes(id));
    sessionStorage.setItem(key, JSON.stringify([...next, String(currentId), ...chosen].slice(-250)));
  } catch { /* Continue without persistence. */ }
  return template.innerHTML;
}
